' Este script ejecuta el PowerShell de forma 100% invisible.
Set objShell = CreateObject("WScript.Shell")

' Comando para ejecutar tu script principal
command = "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File ""%USERPROFILE%\Desktop\nuevo\tortuga\yupilof.ps1"""

' Ejecuta el comando. El "0" significa "ventana oculta".
objShell.Run command, 0, false