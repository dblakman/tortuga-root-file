Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

' Obtiene la ruta de la carpeta donde está este mismo archivo
currentFolder = objFSO.GetParentFolderName(WScript.ScriptFullName)

' Define la ruta al script de PowerShell (debe estar en la misma carpeta)
scriptPath = currentFolder & "\yupilof.ps1"

' Ejecuta el comando de forma 100% invisible
command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File """ & scriptPath & """"
objShell.Run command, 0, false